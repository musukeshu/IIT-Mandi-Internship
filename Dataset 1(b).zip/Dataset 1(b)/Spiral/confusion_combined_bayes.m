clear;
clc;

d1=load('Class1.txt');
d2=load('Class2.txt');

length1=size(d1,1);
length2=size(d2,1);

trainlen1=ceil(length1*0.7);
trainlen2=floor(length2*0.7);

testlen1=length1-trainlen1;
testlen2=length2-trainlen2;
tl=testlen1+testlen2;

A=zeros(tl,1);
A(1:testlen1,1)=1;
A(testlen1+1:tl,1)=2;

trainx1=d1(1:trainlen1,1);
trainy1=d1(1:trainlen1,2);
trainx2=d2(1:trainlen2,1);
trainy2=d2(1:trainlen2,2);

traindata1=[trainx1 trainy1];
traindata2=[trainx2 trainy2];
traindata=[traindata1;traindata2];

testx1=d1(trainlen1+1:length1,1);
testy1=d1(trainlen1+1:length1,2);
testx2=d2(trainlen2+1:length2,1);
testy2=d2(trainlen2+1:length2,2);

testdata1=[testx1 testy1];
testdata2=[testx2 testy2];
testdata = [testdata1;testdata2];

mu1=mean(traindata1);
mu2=mean(traindata2);

% sig1=cov(traindata1);
% sig2=cov(traindata2);
% sig=(sig1+sig2)/2;

sig=cov(traindata);

prior=1/2;

d=2;

testlength=testlen1+testlen2;

g1=zeros(testlength,1);
g2=zeros(testlength,1);

count1=0;
count2=0;
class1=zeros(testlength,1);
for j=1:testlength
    g1(j)=calc_g(testdata(j,:),mu1,sig,prior,d);
    g2(j)=calc_g(testdata(j,:),mu2,sig,prior,d);
    
    if g1(j)>g2(j)
        
        count1=count1+1;
        class1(j)=1;
    
    else  
        count2=count2+1;
        class1(j)=2;
    
    end
end
C=confusionmat(A,class1);
accuracy=trace(C)*100/tl;
plot(traindata1(:,1),traindata1(:,2),'b*');
hold on;
plot(traindata2(:,1),traindata2(:,2),'r*');
hold on;
gscatter(testdata(:,1),testdata(:,2),class1,'br','>>');
hold on;

h = gca;
xylim = [h.XLim h.YLim];
xrange = [xylim(1) xylim(2)];
yrange = [xylim(3) xylim(4)];
inc = 0.2;
[px, py] = meshgrid(xrange(1):inc:xrange(2),yrange(1):inc:yrange(2));
new_test = [px(:) py(:)];
[m,n] =size(new_test);
gn1=zeros(m,1);
gn2=zeros(m,1);
gn3=zeros(m,1);

str=['Accuracy is ',num2str(accuracy),' %'];
hold on
line=[0.01 0.7 0.2 0.1];
annotation('textbox',line,'String',str,'FitBoxTOText','on');
hold on;
bayes_algo(m,gn1,gn2,mu1,mu2,sig,sig,prior,d,new_test);
%legend('test data 1','test data 2','Bound.1','Bound.2');
legend('training data 1','training data 2','test data 1','test data 2','Bound.1','Bound.2');








    






