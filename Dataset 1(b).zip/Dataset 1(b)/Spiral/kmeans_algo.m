function kmeans_algo (class,C,no_clusters,traindata,tl)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
y=100;
g = zeros(tl,no_clusters);
nc = C;
while y>=0
        count=zeros(no_clusters,1);
        sum=zeros(no_clusters,2);
    
    for j=1:tl
         for k=1:no_clusters   
             g(j,k)=distance(traindata(j,:),nc(k,:));
         end
        
        d=min(g(j,:));
        for k=1:no_clusters
            if(d==g(j,k))
                count(k)=count(k)+1;
                class(j)=k;
                sum(k,:)=sum(k,:)+traindata(j,:);
            end
        end
    end
    % c_1=nc1;
    % c_2=nc2;
    % c_3=nc3;
    
   for k=1:no_clusters
       nc(k,:)=sum(k,:)./count(k);
   end
    
    % e1=abs(nc1-c_1);
    % e2=abs(nc2-c_2);
    % e3=abs(nc3-c_3);
    y=y-1;
end
gscatter(traindata(:,1),traindata(:,2),class,'bgr','***');
end





