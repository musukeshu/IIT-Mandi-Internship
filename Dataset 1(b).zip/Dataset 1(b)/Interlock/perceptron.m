d1=load('Class1.txt');
d2=load('Class2.txt');
train=1;

total_len=(size(d1,1)+size(d2,1))*train;
w=rand(2,1);
wo=-1;
learning_par=0.5;


x=[d1(1:size(d1,1)*train,:);d2(1:size(d2,1)*train,:)];

% g1=d1*w+wo;
% g2=d2*w+wo;
% g=[g1;g2];

class=zeros(total_len,1);
class(1:size(d1,1)*train,1)=1;
class(size(d1,1)+1:total_len,1)=-1;

% y=zeros(total_len,1);
y=class;

a=[wo;w];
z=[ones(total_len,1) x];
%figure (2), gscatter(x(:,1),x(:,2),class,'rb','**');
%hold on;
k=0;
a_new=a;
dm=1;
max_iteration=10000;
iteration=0;

while dm>0 && iteration<=max_iteration
    
    g_new=z*a_new;
    dm=0;
    h=zeros(3,1);
    for k=1:total_len
        initial=g_new(k,1)*y(k,1);
        if(initial<0)
           dm=dm+1;
           h=h+y(k,:)*z(k,:)';
        end
    end
         a_old=a_new;
         a_new=a_old+h.*learning_par;
         iteration=iteration+1;
end
gscatter(x(:,1),x(:,2),y,'rb','>>');
hold on
