function bayes_algo (testlength,g1,g2,mu1,mu2,sig1,sig2,prior,d,testdata)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
count1=0;
count2=0;
class1=zeros(testlength,1);
for j=1:testlength
    g1(j)=calc_g(testdata(j,:),mu1,sig1,prior,d);
    g2(j)=calc_g(testdata(j,:),mu2,sig2,prior,d);
    
    if g1(j)>g2(j)
        
        count1=count1+1;
        class1(j)=1;
    
    else  
        count2=count2+1;
        class1(j)=2;
    
    end
end
gscatter(testdata(:,1),testdata(:,2),class1,'yg');
end




