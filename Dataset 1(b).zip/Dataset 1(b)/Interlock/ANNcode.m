clear;
close all;

%loading and preparing the input data having 2 features(elements)
d1=load('Class1.txt');
d2=load('Class2.txt');
d1=d1';
d2=d2';
x=[d1 d2];

%preparing the target 
y=zeros(2,size(x,2));
y(1,1:size(d1,2))=1;
y(2,size(d1,2)+1:size(d1,2)+size(d2,2))=1;

%To avoid the randomness of initial weights
setdemorandstream(491218328);

%making the first neural network 
net=feedforwardnet(4);
view(net);

%providing the training
[net,tr]=train(net,x,y);
nntraintool

%to plot the performance
plotperform(tr);

%this is for testing our data
testX=x(:,tr.testInd);
testY=y(:,tr.testInd);

testT=net(testX);
testIndices=vec2ind(testT);

%using confusion plot
figure(1),plotconfusion(testY,testT);

%calculating the correct and incorrect classification
[c,cm]=confusion(testY,testT);
fprintf('Percentage Correct Classification   : %f%%\n', 100*(1-c));
fprintf('Percentage Incorrect Classification : %f%%\n', 100*c);

%plotting ROC(Receiver operating characteristics
figure(2),plotroc(testY,testT);

%scatter plot of testing data
figure(3),gscatter(testX(1,:),testX(2,:),testIndices,'rb','**');

