function knn_algo( testlen,trainlen,trainlen1,d,class,traindata,testdata,k )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
for i=1:testlen
    count1=0;
    count2=0;
    
    for j=1:trainlen1
        d(j,1)=distance(traindata(j,:),testdata(i,:));
        d(j,2)=1;
    end
    for j=trainlen1+1:trainlen
        d(j,1)=distance(traindata(j,:),testdata(i,:));
        d(j,2)=2;
    end
    dnew=sorting(d);
    for j=1:k
        if dnew(j,2)==1
            count1=count1+1;
        else 
            count2=count2+1;
        end
    end
    if count2>count1 
        class(i)=2;
    else
        class(i)=1;
    end
end
gscatter(testdata(:,1),testdata(:,2),class,'rg');
end

