function [dnew ] = sorting( d )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

for i=1:size(d,1)
    for j=i+1:size(d,1)
        if d(j,1)<d(i,1)
            temp=d(i,1);
            d(i,1)=d(j,1);
            d(j,1)=temp;
            temp=d(i,2);
            d(i,2)=d(j,2);
            d(j,2)=temp;
        end
    end
end
dnew=d;
end

