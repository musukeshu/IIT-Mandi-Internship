clear ;
close all;

d1=load('Class1.txt');
d2=load('Class2.txt');

length1=size(d1,1);
length2=size(d2,1);

train1=length1*0.7;
train2=length2*0.7;

testlen1=length1-train1;
testlen2=length2-train2;

traindata1=d1(1:train1,:);
traindata2=d2(1:train2,:);
traindata=[traindata1;traindata2];

testdata1=d1(train1+1:length1,:);
testdata2=d2(train2+1:length2,:);
testdata=[testdata1;testdata2];

class=zeros(length1+length2,1);
class(1:length1,:)=1;
class(length1+1:length1+length2,:)=2;

group1=class(1:train1,:);
group2=class(length1+1:length1+train2,:);
group=[group1;group2];
% group=[1;2];
sigma = 0.09;
svmStruct=svmtrain(traindata,group,'Kernel_Function','rbf','RBF_Sigma',sigma,'showplot',true);
title(sprintf('Kernel Function: %s',func2str(svmStruct.KernelFunction)),'interpreter','none');
classes=svmclassify(svmStruct,testdata,'showplot',true);

actual1=class(train1+1:length1,:);
actual2=class(length1+train2+1:length1+length2,:);
actual=[actual1;actual2];
count=0;
for i=1:size(actual,1)
    if actual(i,1)~=classes(i,1)
        count=count+1;
    end
end

accuracy=(testlen1+testlen2-count)/(testlen1+testlen2)*100;

str=['Accuracy is ',num2str(accuracy),' %'];
line=[0.03 0.7 0.2 0.1];
annotation('textbox',line,'String',str,'FitBoxTOText','on');



