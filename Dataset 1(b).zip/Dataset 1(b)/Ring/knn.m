d1=load('Class1.txt');
d2=load('Class2.txt');


trainlen1=size(d1,1)*0.7;
trainlen2=size(d2,1)*0.7;


testlen1=size(d1,1)-trainlen1;
testlen2=size(d2,1)-trainlen2;


traindata1=d1(1:trainlen1,:);
traindata2=d2(1:trainlen2,:);
traindata=[traindata1;traindata2];
trainlen=size(traindata,1);

testdata1=d1(trainlen1+1:size(d1,1),:);
testdata2=d2(trainlen2+1:size(d2,1),:);

testdata=[testdata1;testdata2];
testlen=size(testdata,1);

k=10;

d=zeros(trainlen,2);
class=zeros(testlen,1);

knn_algo( testlen,trainlen,trainlen1,d,class,traindata,testdata,k );
hold on;
h = gca;
xylim = [h.XLim h.YLim];
xrange = [xylim(1) xylim(2)];
yrange = [xylim(3) xylim(4)];
inc = 0.03;
[px, py] = meshgrid(xrange(1):inc:xrange(2),yrange(1):inc:yrange(2));
new_test = [px(:) py(:)];
[m,n] =size(new_test);
knn_algo( m,trainlen,trainlen1,d,class,traindata,new_test,k );
        
    
        