function [ class] = lrclassifier( Xtest,theta )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
testsize=size(Xtest,1);
class=zeros(testsize,1);
for k=1:testsize
    sig=sigmoid([1,Xtest(k,:)]*theta);
    if(sig>=0.5)
        class(k)=1;
    else
        class(k)=0;
    end
end

end

