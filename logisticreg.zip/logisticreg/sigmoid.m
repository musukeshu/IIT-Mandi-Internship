function [ g_z ] = sigmoid( z)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
g_z=1/(1+exp(-z));

end

