function [ J ] = Cost_algo( Xtrain,theta,Ytrain)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

tsamples=size(Xtrain,1);
temp=0;
for k=1:tsamples
    z=sigmoid(([1 Xtrain(k,:)])*theta);
    if(Ytrain(k)==1)
        temp=temp+log(z);
    else
        temp=temp+log(1-z);
    end
end
J=temp/(-tsamples);
end

