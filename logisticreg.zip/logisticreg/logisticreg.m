clear ;
close all;
clc;

d1=load('logistic regression data.txt');
X=d1(:,1:2);
Y=d1(:,3);

[totsamples ,totfeatures]=size(X);

trainsamples=totsamples*0.75;
testsamples=totsamples-trainsamples;

Xtrain=X(1:trainsamples,:);
Ytrain=Y(1:trainsamples,:);

Xtest=X(trainsamples+1:totsamples,:);
Ytest=Y(trainsamples+1:totsamples,:);

thetao=rand(totfeatures+1,1);
iteration=100;
alpha=0.001;

%calling the optimisation gradient decent algo.
theta=calculate_theta(Xtrain,Ytrain,thetao,iteration,alpha);

class=lrclassifier(Xtest,theta);

figure(2), gscatter(Xtrain(:,1),Xtrain(:,2),Ytrain,'br','**');
hold on;

% h = gca;
% xylim = [h.XLim h.YLim];
% xrange = [xylim(1) xylim(2)];
% yrange = [xylim(3) xylim(4)];
% inc = 1;
% [px, py] = meshgrid(xrange(1):inc:xrange(2),yrange(1):inc:yrange(2));
% new_test = [px(:) py(:)];
% [m,n] =size(new_test);
% 
% class1=lrclassifier(new_test,theta);
% gscatter(new_test(:,1),new_test(:,2),class1,'cy');
% hold on


gscatter(Xtest(:,1),Xtest(:,2),class,'br','>>');
hold on
gscatter(Xtest(:,1),Xtest(:,2),Ytest,'br','..');
hold on;
legend('Training class 1','Training class 2','calculated class 1','calculated class 2','Actual class 1','Actual class 2');
% calculating the accuracy

error=abs(class-Ytest);
err=sum(error);
accuracy=(1-err(1)/testsamples)*100;
disp(accuracy);



