function [ theta ] = calculate_theta(Xtrain,Ytrain,thetao,iteration,alpha)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[tsamples ,tfeatures]=size(Xtrain);

precost=0;
theta=thetao;
totalCost = zeros(iteration,1);

for j=1:iteration
    temp=zeros(tfeatures+1,1);
    for k=1:tsamples
    temp=temp+(sigmoid([1 Xtrain(k,:)]*theta)-Ytrain(k,:))*([1,Xtrain(k,:)])';
    end
    theta=theta-alpha*(temp./tsamples);
    cost=Cost_algo(Xtrain,theta,Ytrain);
    totalCost(j) = cost;

    if abs(cost-precost)/cost<=0.0001
        break;
    end
    precost=cost;
end
figure(1)
hold on
plot(1:iteration,totalCost,'-');

end

