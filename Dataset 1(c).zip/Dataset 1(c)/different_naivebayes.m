clear;
clc;

d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');
d4=load('Class4.txt');

length1=size(d1,1);
length2=size(d2,1);
length3=size(d3,1);
length4=size(d4,1);

trainlen1=ceil(length1*0.7);
trainlen2=ceil(length2*0.7);
trainlen3=ceil(length3*0.7);
trainlen4=ceil(length4*0.7);

testlen1=length1-trainlen1;
testlen2=length2-trainlen2;
testlen3=length3-trainlen3;
testlen4=length4-trainlen4;

trainx1=d1(1:trainlen1,1);
trainy1=d1(1:trainlen1,2);
trainx2=d2(1:trainlen2,1);
trainy2=d2(1:trainlen2,2);
trainx3=d3(1:trainlen3,1);
trainy3=d3(1:trainlen3,2);
trainx4=d4(1:trainlen4,1);
trainy4=d4(1:trainlen4,2);

traindata1=[trainx1 trainy1];
traindata2=[trainx2 trainy2];
traindata3=[trainx3 trainy3];
traindata4=[trainx4 trainy4];
traindata=[traindata1;traindata2;traindata3;traindata4];

testx1=d1(trainlen1+1:length1,1);
testy1=d1(trainlen1+1:length1,2);
testx2=d2(trainlen2+1:length2,1);
testy2=d2(trainlen2+1:length2,2);
testx3=d3(trainlen3+1:length3,1);
testy3=d3(trainlen3+1:length3,2);
testx4=d4(trainlen4+1:length4,1);
testy4=d4(trainlen4+1:length4,2);

testdata1=[testx1 testy1];
testdata2=[testx2 testy2];
testdata3=[testx3 testy3];
testdata4=[testx4 testy4];
testdata = [testdata1;testdata2;testdata3;testdata4];

mu1=mean(traindata1);
mu2=mean(traindata2);
mu3=mean(traindata3);
mu4=mean(traindata4);

sig1=diag(diag(cov(traindata1)));
sig2=diag(diag(cov(traindata2)));
sig3=diag(diag(cov(traindata3)));
sig4=diag(diag(cov(traindata4)));
%sig=cov(traindata);

prior=1/4;

d=2;

testlength=testlen1+testlen2+testlen3+testlen4;

g1=zeros(testlength,1);
g2=zeros(testlength,1);
g3=zeros(testlength,1);
g4=zeros(testlength,1);


bayes_algo(testlength,g1,g2,g3,g4,mu1,mu2,mu3,mu4,sig1,sig2,sig3,sig4,prior,d,testdata);
hold on;
h = gca;
xylim = [h.XLim h.YLim];
xrange = [xylim(1) xylim(2)];
yrange = [xylim(3) xylim(4)];
inc = 0.2;
[px, py] = meshgrid(xrange(1):inc:xrange(2),yrange(1):inc:yrange(2));
new_test = [px(:) py(:)];
[m,n] =size(new_test);
gn1=zeros(m,1);
gn2=zeros(m,1);
gn3=zeros(m,1);
gn4=zeros(m,1);

bayes_algo(m,gn1,gn2,gn3,gn4,mu1,mu2,mu3,mu4,sig1,sig2,sig3,sig4,prior,d,new_test);








    






