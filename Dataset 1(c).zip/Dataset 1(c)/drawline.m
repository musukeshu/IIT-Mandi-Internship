%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program For Drawing Line                                           %
% Program Written By Sharad K. Gupta, Srishti Gautam, Kanhaiya Kumar %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function h = drawline(p,scale)
    x = p(2);
    y = p(3);
    w0 = p(1);

    mod_w = sqrt(x*x+y*y);
    k = -w0/(mod_w*mod_w);

    nx = x/mod_w;
    ny = y/mod_w;

    h = line([k*x-ny*scale k*x+ny*scale], [k*y+nx*scale k*y-nx*scale]);
end
    