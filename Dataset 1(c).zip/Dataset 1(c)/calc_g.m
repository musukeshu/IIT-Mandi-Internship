function [ g ] = calc_g(x,mu,sig,prior,d)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
g=(-1/2)*(x-mu)*(sig\(x-mu)') - (d/2)*log(2*pi) + (-1/2)*log(det(sig)) + log(prior);
end

