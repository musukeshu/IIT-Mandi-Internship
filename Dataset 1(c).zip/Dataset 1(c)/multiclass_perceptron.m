d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');

no_of_classes=3;

x=[d1;d2;d3];
total_len=size(x,1);

label1=zeros(total_len,1);
label1(1:size(d1,1),1)=1;
label1(size(d1,1)+1:total_len,1)=-1;

label2=zeros(total_len,1);
label2(1:size(d1,1),1)=-1;
label2(size(d1,1)+1:size(d1,1)+size(d2,1),1)=1;
label2(size(d1,1)+size(d1,1)+1:total_len,1)=-1;

label3=zeros(total_len,1);
label3(1:size(d1,1)+size(d2,1),1)=-1;
label3(size(d1,1)+size(d2,1)+1:total_len,1)=1;

w=rand(2,1);
wo=-1;
learning_par=0.5;
a1=[wo;w];
z=[ones(total_len,1) x];
a_new1=a1;
dm=1;
max_iteration=10000;
iteration=0;
while dm>0 && iteration<=max_iteration
    
    g_new=z*a_new1;
    dm=0;
    h=zeros(3,1);
    for k=1:total_len
        initial=g_new(k,1)*label1(k,1);
        if(initial<0)
           dm=dm+1;
           h=h+label1(k,:)*z(k,:)';
        end
    end
         a_old1=a_new1;
         a_new1=a_old1+h.*learning_par;
         iteration=iteration+1;
end
figure(1),gscatter(x(:,1),x(:,2),label1,'rb','>*');
hold on
drawline(a_new1,16);

learning_par=0.5;
a2=[wo;w];
z=[ones(total_len,1) x];
a_new2=a1;
dm=1;
max_iteration=10000;
iteration=0;
while dm>0 && iteration<=max_iteration
    
    g_new=z*a_new2;
    dm=0;
    h=zeros(3,1);
    for k=1:total_len
        initial=g_new(k,1)*label2(k,1);
        if(initial<0)
           dm=dm+1;
           h=h+label2(k,:)*z(k,:)';
        end
    end
         a_old2=a_new2;
         a_new2=a_old2+h.*learning_par;
         iteration=iteration+1;
end
figure(2),gscatter(x(:,1),x(:,2),label2,'rb','*.');
hold on
drawline(a_new2,16);


learning_par=0.5;
a3=[wo;w];
z=[ones(total_len,1) x];
a_new3=a3;
dm=1;
max_iteration=10000;
iteration=0;
while dm>0 && iteration<=max_iteration
    
    g_new=z*a_new3;
    dm=0;
    h=zeros(3,1);
    for k=1:total_len
        initial=g_new(k,1)*label3(k,1);
        if(initial<0)
           dm=dm+1;
           h=h+label3(k,:)*z(k,:)';
        end
    end
         a_old3=a_new3;
         a_new3=a_old3+h.*learning_par;
         iteration=iteration+1;
end
figure(3),gscatter(x(:,1),x(:,2),label3,'rb','.*');
hold on
drawline(a_new3,16);

f1=z*a_new1;
f2=z*a_new2;
f3=z*a_new3;

f=[f1 f2 f3];
predicted_class=zeros(total_len,1);

for k=1:total_len
    maximum=max(f(k,:));
    if maximum==f(k,1)
        predicted_class(k,1)=1;
    elseif maximum==f(k,2)
        predicted_class(k,1)=2;
    else
        predicted_class(k,1)=3;
    end
end
figure(4),gscatter(x(:,1),x(:,2),predicted_class,'rbg','.*>');
hold on;
        
    
