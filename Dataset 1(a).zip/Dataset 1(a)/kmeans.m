clear;
clc;

d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');

length1=size(d1,1);
length2=size(d2,1);
length3=size(d3,1);

trainlen1=length1;
trainlen2=length2;
trainlen3=length3;
tl=trainlen1+trainlen2+trainlen3;

% testlen1=length1-trainlen1;
% testlen2=length2-trainlen2;
% testlen3=length3-trainlen3;

traindata1=d1(1:trainlen1,:);
traindata2=d2(1:trainlen2,:);
traindata3=d3(1:trainlen3,:);
traindata=[traindata1;traindata2;traindata3];

% mean1=mean(traindata1);
% mean2=mean(traindata2);
% mean3=mean(traindata3);

% C=rand(3,2);

% c1=C(1,:);
% c2=C(2,:);
% c3=C(3,:);
no_clusters=3;

randpts = floor(1+(tl-1)*rand(no_clusters,1));

C=traindata(randpts,:);
% plot(traindata(:,1),traindata(:,2),'.')
% hold on
% e1=abs(c1);
% e2=abs(c2);
% e3=abs(c3);

% x=[0 0];

class=zeros(tl,1);
kmeans_algo(class,C,no_clusters,traindata,tl);


