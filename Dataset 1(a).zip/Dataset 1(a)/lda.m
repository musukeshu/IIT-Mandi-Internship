d1=load('Class1.txt');
d2=load('Class2.txt');
n1=size(d1,1);
n2=size(d2,1);
u1=(sum(d1)./n1);
u2=(sum(d2)./n2);
% u11=diag(u1);
% u22=diag(u2);
% s1=0;
% s2=0;
s1 = (sum(sum((d1-u1)'*(d1-u1))));
s2 = (sum(sum((d2-u2)'*(d2-u2))));

% for i=1:n1
%     s1=s1+((d1(i,:)-u1)*(d1(i,:)-u1)');
% end
% for i=1:n2
%     s2=s2+((d2(i,:)-u1)*(d2(i,:)-u1)');
% end
Sw=s1+s2;
w=(u2-u1)/Sw;
x1=d1*(w)';
x2=d2*(w)';
plot(x1,0,'b.');
hold on;
plot(x2,0,'g.');