d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');

trainlen1=size(d1,1)*0.7;
trainlen2=size(d2,1)*0.7;
trainlen3=size(d3,1)*0.7;

testlen1=size(d1,1)-trainlen1;
testlen2=size(d2,1)-trainlen2;
testlen3=size(d3,1)-trainlen3;

traindata1=d1(1:trainlen1,:);
traindata2=d2(1:trainlen2,:);
traindata3=d3(1:trainlen3,:);
traindata=[traindata1;traindata2;traindata3];
trainlen=size(traindata,1);

testdata1=d1(trainlen1+1:size(d1,1),:);
testdata2=d2(trainlen2+1:size(d2,1),:);
testdata3=d3(trainlen3+1:size(d3,1),:);
testdata=[testdata1;testdata2;testdata3];
testlen=size(testdata,1);

k=10;

d=zeros(trainlen,2);
class=zeros(testlen,1);

for i=1:testlen
    count1=0;
    count2=0;
    count3=0;
    for j=1:trainlen1
        d(j,1)=distance(traindata(j,:),testdata(i,:));
        d(j,2)=1;
    end
    for j=trainlen1+1:trainlen1+trainlen2
        d(j,1)=distance(traindata(j,:),testdata(i,:));
        d(j,2)=2;
    end
    for j=trainlen1+trainlen2+1:trainlen
        d(j,1)=distance(traindata(j,:),testdata(i,:));
        d(j,2)=3;
    end
    dnew=sorting(d);
    for j=1:k
        if dnew(j,2)==1
            count1=count1+1;
        elseif dnew(j,2)==2
            count2=count2+1;
        else
            count3=count3+1;
        end
    end
    if count2>count1 && count2>count3
        class(i)=2;
    elseif count1>count2 && count1>count3
        class(i)=1;
    else
        class(i)=3;
    end
end
gscatter(testdata(:,1),testdata(:,2),class,'rgb');
            
        
        
    
        