function [g]= distance(mu,x)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

g=(x-mu)*(x-mu)';
end

