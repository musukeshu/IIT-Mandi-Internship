function [ classss ] = multisvm( traindata1,traindata2,traindata3,group1,group2,group3,testdata1,testdata2,testdata3,testdata) 
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
traindata12=[traindata1;traindata2];
group12=[group1;group2];
testdata12=[testdata1;testdata2];
figure(1),
class12=svmalgo(traindata12,group12,testdata12);

traindata13=[traindata1;traindata3];
group13=[group1;group3];
testdata13=[testdata1;testdata3];
figure(2),
class13=svmalgo(traindata13,group13,testdata13);

class1=[class12 class13];


traindata21=[traindata2;traindata1];
group21=[group2;group1];
testdata21=[testdata2;testdata1];
class21=svmalgo(traindata21,group21,testdata21);

traindata23=[traindata2;traindata3];
group23=[group2;group3];
testdata23=[testdata2;testdata3];
figure(3),
class23=svmalgo(traindata23,group23,testdata23);

class2=[class21 class23];


traindata31=[traindata3;traindata1];
group31=[group3;group1];
testdata31=[testdata3;testdata1];
class31=svmalgo(traindata31,group31,testdata31);

traindata32=[traindata3;traindata2];
group32=[group3;group2];
testdata32=[testdata3;testdata2];
class32=svmalgo(traindata32,group32,testdata32);

class3=[class31 class32];

class123=[class1;class2;class3];
testdata=[testdata1;testdata2;testdata3];

classss=zeros(size(testdata,1),1);
i=1;
for k=1:size(class123,1)
    if class123(k,1)==class123(k,2)
        classss(i,1)=class123(k,1);
        i=i+1;
    end
end

end

