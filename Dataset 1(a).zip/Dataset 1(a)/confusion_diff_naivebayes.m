clear;
clc;

d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');

length1=size(d1,1);
length2=size(d2,1);
length3=size(d3,1);

trainlen1=length1*0.7;
trainlen2=length2*0.7;
trainlen3=length3*0.7;

testlen1=length1-trainlen1;
testlen2=length2-trainlen2;
testlen3=length3-trainlen3;
tl=testlen1+testlen2+testlen3;
A=zeros(tl,1);
A(1:testlen1,1)=1;
A(testlen1+1:testlen1+testlen2,1)=2;
A(testlen1+testlen2+1:tl)=3;


trainx1=d1(1:trainlen1,1);
trainy1=d1(1:trainlen1,2);
trainx2=d2(1:trainlen2,1);
trainy2=d2(1:trainlen2,2);
trainx3=d3(1:trainlen3,1);
trainy3=d3(1:trainlen3,2);

traindata1=[trainx1 trainy1];
traindata2=[trainx2 trainy2];
traindata3=[trainx3 trainy3];

testx1=d1(trainlen1+1:length1,1);
testy1=d1(trainlen1+1:length1,2);
testx2=d2(trainlen2+1:length2,1);
testy2=d2(trainlen2+1:length2,2);
testx3=d3(trainlen3+1:length3,1);
testy3=d3(trainlen3+1:length3,2);

testdata1=[testx1 testy1];
testdata2=[testx2 testy2];
testdata3=[testx3 testy3];
testdata = [testdata1;testdata2;testdata3];

mu1=mean(traindata1);
mu2=mean(traindata2);
mu3=mean(traindata3);

sig1=diag(diag(cov(traindata1)));
sig2=diag(diag(cov(traindata2)));
sig3=diag(diag(cov(traindata3)));

prior=1/3;

d=2;

testlength=testlen1+testlen2+testlen3;

g1=zeros(testlength,1);
g2=zeros(testlength,1);
g3=zeros(testlength,1);

count1=0;
count2=0;
count3=0;

class=zeros(testlength,1);

for j=1:testlength
    g1(j)=calc_g(testdata(j,:),mu1,sig1,prior,d);
    g2(j)=calc_g(testdata(j,:),mu2,sig2,prior,d);
    g3(j)=calc_g(testdata(j,:),mu3,sig3,prior,d);
    
    if g1(j)>g2(j) && g1(j)>g3(j)
        count1=count1+1;
        class(j)=1;
    
    elseif  g2(j)>g1(j) && g2(j)>g3(j)
        count2=count2+1;
        class(j)=2;
    
    else
        count3=count3+1;
        class(j)=3;
    end
end
plot(traindata1(:,1),traindata1(:,2),'b*');
hold on;
plot(traindata2(:,1),traindata2(:,2),'r*');
hold on;
plot(traindata3(:,1),traindata3(:,2),'k*');
hold on;
gscatter(testdata(:,1),testdata(:,2),class,'brk','>>>');

h = gca;
xylim = [h.XLim h.YLim];
xrange = [xylim(1) xylim(2)];
yrange = [xylim(3) xylim(4)];
inc = 0.2;
[px, py] = meshgrid(xrange(1):inc:xrange(2),yrange(1):inc:yrange(2));
new_test = [px(:) py(:)];
[m,n] =size(new_test);
class_new = zeros(m,1);
c1=0;
c2=0;
c3=0;

gn1=zeros(m,1);
gn2=zeros(m,1);
gn3=zeros(m,1);

for j=1:m
    gn1(j)=calc_g(new_test(j,:),mu1,sig1,prior,d);
    gn2(j)=calc_g(new_test(j,:),mu2,sig2,prior,d);
    gn3(j)=calc_g(new_test(j,:),mu3,sig3,prior,d);
    
    if gn1(j)>gn2(j) && gn1(j)>gn3(j)
        c1=c1+1;
        class_new(j)=1;
    
    elseif  gn2(j)>gn1(j) && gn2(j)>gn3(j)
        c2=c2+1;
        class_new(j)=2;
    
    else
        c3=c3+1;
        class_new(j)=3;
    end
end
C=confusionmat(A,class);
accuracy=trace(C)*100/tl;
str=['Accuracy is ',num2str(accuracy),' %'];
hold on
gscatter(new_test(:,1),new_test(:,2),class_new,'ygc');
line=[0.03 0.7 0.2 0.1];
annotation('textbox',line,'String',str,'FitBoxTOText','on');
legend('Training data 1','Training data 2','Training data 3','Test data 1','Test data 2','Test data 3','Bound 1','Bound 2','Bound 3');
%legend('Test data 1','Test data 2','Test data 3','Bound 1','Bound 2','Bound 3');









    






