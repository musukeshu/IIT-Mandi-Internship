function [x1,x2]= fisher_lda( d1,d2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

s1=cov(d1);
s2=cov(d2);
sw=s1+s2;
if(det(sw)==0)
    sw=sw+0.35*eye(size(sw));
end
w=sw\(mean(d1)-mean(d2))';  %w=inv(sw)*(mean(d1)-mean(d2))'
x1=d1*w;
x2=d2*w;
plot(x1,0,'b.');
hold on;
plot(x2,0,'g.');
end