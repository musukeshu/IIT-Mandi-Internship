clear ;
close all;

d1=load('Class1.txt');
d2=load('Class2.txt');
d3=load('Class3.txt');
d=[d1;d2;d3];

length1=size(d1,1);
length2=size(d2,1);
length3=size(d3,1);
total_length=length1+length2+length3;

train1=length1*0.7;
train2=length2*0.7;
train3=length3*0.7;
total_train=train1+train2+train3;

testlen1=length1-train1;
testlen2=length2-train2;
testlen3=length3-train3;
total_test=testlen1+testlen2+testlen3;

traindata1=d1(1:train1,:);
traindata2=d2(1:train2,:);
traindata3=d3(1:train3,:);
traindata=[traindata1;traindata2;traindata3];

testdata1=d1(train1+1:length1,:);
testdata2=d2(train2+1:length2,:);
testdata3=d3(train3+1:length3,:);
testdata=[testdata1;testdata2;testdata3];

class=zeros(total_length,1);

class(1:length1,:)=1;
class(length1+1:length1+length2,:)=2;
class(length1+length2+1:total_length,:)=3;

group1=class(1:train1,:);
group2=class(length1+1:length1+train2,:);
group3=class(length1+length2+1:length1+length2+train3,:);
group=[group1;group2;group3];

results=multisvm(traindata1,traindata2,traindata3,group1,group2,group3,testdata1,testdata2,testdata3,testdata);
figure(4),
gscatter(traindata(:,1),traindata(:,2),group,'rgb','***');
hold on;
gscatter(testdata(:,1),testdata(:,2),results,'brg','>>>');
hold on;

