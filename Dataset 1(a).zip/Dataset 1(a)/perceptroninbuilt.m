x=load('Class1.txt');
y=load('Class2.txt');

xy=[x;y];

lengthx=size(x,1);
lengthy=size(y,1);

trainx=size(x,1)*0.7;
trainy=size(y,1)*0.7;

testx=lengthx-trainx;
testy=lengthy-trainy;

traindatax=x(1:trainx,:);
traindatay=y(1:trainy,:);
traindata=[traindatax;traindatay];

testdatax=x(trainx+1:lengthx,:);
testdatay=y(trainy+1:lengthy,:);
testdata=[testdatax;testdatay];

net=perceptron;
net=train(net,traindata,testdata);
view(net);
z=net(traindata);