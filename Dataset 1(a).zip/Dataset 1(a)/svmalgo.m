function [ classes ] = svmalgo(traindata,group,testdata)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
svmStruct=svmtrain(traindata,group,'Kernel_Function','rbf','showplot',true);
classes=svmclassify(svmStruct,testdata,'showplot',true);
end

