%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program For Simple Perceptron                                      %
% Program Written By Sharad K. Gupta								 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function simplePerceptron()
	clc; clear all; close all;
    tic;
    
	data{1}=load('Class1.txt');
	data{2}=load('Class2.txt');
    data{3}=load('Class3.txt');
    
    noOfClasses = 3;
    trainComb = cell(noOfClasses,1);
    
    for class = 1:noOfClasses
        noOfExamples(class) = size(data{class},1);
        noOfTrainingExamples(class) = uint16(0.75*noOfExamples(class));
        noOfTestingExamples(class) = uint16(noOfExamples(class) - noOfTrainingExamples(class));
        trainingExamples{class} = data{class}(1:noOfTrainingExamples(class),:);
        testingExamples{class} = data{class}(noOfTrainingExamples(class)+1:noOfExamples(class),:);
        classOfTrainingExamples{class} = class*ones(noOfTrainingExamples(class),1);
        classOfTestingExamples{class} = class*ones(noOfTestingExamples(class),1);
    end

    trainComb{1} = [trainingExamples{1};trainingExamples{2}];   % Class 1 & Class 2
    trainComb{2} = [trainingExamples{2};trainingExamples{3}];   % Class 2 & Class 3
    trainComb{3} = [trainingExamples{1};trainingExamples{3}];   % Class 3 & Class 1
    
	classlabel{1} = [ones(noOfTrainingExamples(1),1);(-1).*ones(noOfTrainingExamples(2),1)];    % Class 1 & Class 2
    classlabel{2} = [ones(noOfTrainingExamples(2),1);(-1).*ones(noOfTrainingExamples(3),1)];    % Class 2 & Class 3
    classlabel{3} = [ones(noOfTrainingExamples(1),1);(-1).*ones(noOfTrainingExamples(3),1)];    % Class 3 & Class 1
    total = sum(noOfTestingExamples);
    totalTesting = [testingExamples{1};testingExamples{2};testingExamples{3}];
    totalTesting_A = [totalTesting,ones(total,1)]; % Augmented Testing Data
    actualTest = [classOfTestingExamples{1};classOfTestingExamples{2};classOfTestingExamples{3}];
        
	%% Perceptron Algorithm
    
    symbols = {'o^','+o','+^'};
    plotStyle = {'rg','br','bg'};
	
    for class = 1:noOfClasses
        
        [rows,~] = size(trainComb{class});
        neeta = 0.05; %Learning Rate
        trainingExamples_A = [trainComb{class},ones(rows,1)];
        [rows_A,columns_A] = size(trainingExamples_A);
%         w = [rand().*ones(columns_A-1,1);1]; %Initial Weight
        w = [0.03;1.4;1];
        maxIteration = 10000;
        iteration = 0;
        Dm = 1; %No. of missclassified vectors

        while (Dm > 0) && (iteration < maxIteration) %Stopping Criteria i.e. if No. of Misclassified Vectors are Zero (Dm = 0)
            figure(class);gscatter(trainComb{class}(:,1),trainComb{class}(:,2),classlabel{class},plotStyle{class},symbols{class},4);
            hold on;
            axis([-25 25,-25 25]);
            iteration = iteration + 1;
            Dm = 0;
            gradient = zeros(columns_A,1);
            strEq = sprintf('(%f) * x + (%f) * y + (%f) = 0',w(1),w(2),w(3));
            hold off
            title(strEq);
            drawline(w,32);
            pause(0.1)
            for i = 1:rows_A
                temp = trainingExamples_A(i,:)';
                if ((classlabel{class}(i,1)*(w'*temp)) < 0) % if (y*(a'z)<0)
                    Dm = Dm + 1;
                    gradient = gradient + (classlabel{class}(i,1)*temp);
                end
            end
            fprintf('\n %d Iteration: # Misclassified points = %g \n',iteration,Dm);
            w = w + (neeta*gradient);
        end
        oldw{class} = w;
    end
    
    %% Test Data Classification
    
    for i = 1:size(totalTesting_A,1)
        temp1 = totalTesting_A(i,:);
        if (temp1*oldw{1}) > 0
            tempAssgnClass(i,1) = 1;
        elseif (temp1*oldw{1}) < 0
            tempAssgnClass(i,1) = 2;
        end
        if (temp1*oldw{2}) > 0
            tempAssgnClass(i,2) = 2;
        elseif (temp1*oldw{2}) < 0
            tempAssgnClass(i,2) = 3;
        end
        if (temp1*oldw{3}) > 0
            tempAssgnClass(i,3) = 1;
        elseif (temp1*oldw{3}) < 0
            tempAssgnClass(i,3) = 3;
        end
        a = tempAssgnClass(i,:);
        for k = 1:noOfClasses
            b(k) = length(find(a == k));
        end
        [~,assgnClasses(i,1)] = max(b);
    end
    
    %% Final Output  
    
    figure;hold on;
    symbols = {'^','o','+'};
    plotStyle = {'g','r','b'};
%     gscatter(totalTesting(:,1),totalTesting(:,2),assgnClasses,'rgb','^o+',4);
    
    for class = 1:noOfClasses
        gscatter(trainingExamples{class}(:,1),trainingExamples{class}(:,2),classOfTrainingExamples{class},plotStyle{class},symbols{class},4);
        a = oldw{class};
        h = drawline(a,40);
        h.Color = plotStyle{class};
    end
    legend('Class 1','Line 1','Class 2','Line 2','Class 3','Line 3');
    confusion_matrix=confusionmat(actualTest,assgnClasses)
    Accuracy=100*(trace(confusion_matrix)/size(totalTesting,1));
    fprintf('Accuracy of Overall Classification is %0.3f Percent\n', Accuracy);
    for i=1:size(unique(assgnClasses))
        precision(i)=100*(confusion_matrix(i,i)/sum(confusion_matrix(:,i)));
        fprintf('Precision for Class %d is %0.3f Percent\n', i,precision(i));
    end
    for i=1:size(unique(assgnClasses))
        recall(i)=100*(confusion_matrix(i,i)/sum(confusion_matrix(i,:)));
        fprintf('Recall for Class %d is %0.3f Percent\n', i,recall(i));
    end
    TimeTaken = toc
    
end